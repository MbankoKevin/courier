@if($html->html)
    <div class="card mb-5 p-4" style="border: 6px solid rgba(0, 0, 0, 0.05);background-color: inherit;">
        {!! $html->html !!}
    </div>
@endif